Este proyecto es una página web básica desarrollada como parte de un curso de Front-End. La página está estructurada con HTML semántico y utiliza las etiquetas <header>, <main>, y <footer> para organizar el contenido. El objetivo es aprender a crear la estructura básica de una página web y prepararla para futuras mejoras con CSS y JavaScript.

Este sitio web contiene los ejemplos(HTML, CSS, JS) que vamos viendo durante la cursada separadas por clases.

4/4
Primera Versión clase 1 y 2
Agregar Menú